1. Go to Lab1 folder

2. compile
g++ main.cpp

3. execute
./a.out ./Data/input-1

You can type ay input like input-5 instead of input-1